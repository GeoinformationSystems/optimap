#!/bin/sh -e
#python manage.py migrate
#python manage.py createcachetable
echo "Release does nothing anymore, all in etc/manage-and-run.sh"

